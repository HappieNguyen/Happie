#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int main ()
{
    int number;
    string fileName;
    ifstream inputFile;

    cout << "What file do you want to open? ";
    cin >> fileName;
    inputFile.open(fileName);

    //if the file is successfully opened, process it
    if (inputFile)
    {
        //read the number from the file and display them
        while (inputFile >> number)
        {
            cout << number << endl;
        }

        //Close the file
        inputFile.close();
    }
    else
    {
        //Display error message
        cout << "Error opening the file.\n";
    }

    return 0;
}